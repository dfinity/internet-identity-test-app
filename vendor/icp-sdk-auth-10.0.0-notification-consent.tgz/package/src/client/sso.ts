// The identity provider's cap on the domain it will fetch.
const MAX_AUTHORITY_LENGTH = 255;

const WELL_KNOWN_PATH = '/.well-known/ii-openid-configuration';

/**
 * `localhost` / `127.0.0.1`, optionally followed by `:<port>`. IPv6 loopback
 * (`[::1]`, etc.) is intentionally not handled — the identity provider doesn't
 * recognise it either, and its e2e setup uses the hostname form.
 */
function isLoopbackHost(host: string): boolean {
  let url: URL;
  try {
    // Parse as a URL authority so the optional `:<port>` is split off for us
    // rather than by hand. Invalid input throws and is treated as non-loopback.
    url = new URL(`http://${host}`);
  } catch {
    return false;
  }
  // A bare `host[:port]` has no path/query/fragment; reject e.g. `localhost/x`.
  if (url.pathname !== '/' || url.search !== '' || url.hash !== '') {
    return false;
  }
  return url.hostname === 'localhost' || url.hostname === '127.0.0.1';
}

/**
 * Normalizes an SSO domain to the authority the identity provider fetches the
 * discovery document from: lowercased, IDNA-encoded, host and optional port.
 *
 * @param domain - The organization domain.
 * @returns The normalized authority.
 * @throws When `domain` is not a domain with an optional port.
 */
export function normalizeSsoDomain(domain: string): string {
  const trimmed = domain.trim();
  if (trimmed.length === 0) {
    throw new Error('ssoDomain cannot be empty');
  }
  let url: URL;
  try {
    url = new URL(`https://${trimmed}`);
  } catch {
    throw new Error(`ssoDomain is not a domain: ${trimmed}`);
  }
  const authority = url.host;
  // Rebuilding from the host and port alone has to reproduce what was parsed,
  // so anything else the domain carried shows up as a difference.
  if (new URL(`https://${authority}`).href !== url.href) {
    throw new Error(`ssoDomain must be a domain and optional port, nothing else: ${trimmed}`);
  }
  if (authority.length > MAX_AUTHORITY_LENGTH) {
    throw new Error(`ssoDomain exceeds ${MAX_AUTHORITY_LENGTH} characters`);
  }
  // A bare hostname is a half-typed domain, not something worth a request.
  if (!authority.includes('.') && !isLoopbackHost(authority)) {
    throw new Error(`ssoDomain is not a domain name: ${trimmed}`);
  }
  return authority;
}

function publishesSsoConfiguration(value: unknown): boolean {
  if (typeof value !== 'object' || value === null) {
    return false;
  }
  const { client_id, openid_configuration } = value as Record<string, unknown>;
  return typeof client_id === 'string' && typeof openid_configuration === 'string';
}

/**
 * Checks whether an organization domain can be used for SSO sign-in: it is a
 * domain name, and it publishes `/.well-known/ii-openid-configuration` with a
 * `client_id` and an `openid_configuration` URL.
 *
 * The document must be served with `Access-Control-Allow-Origin: *`.
 *
 * The check waits on a third-party server and has no deadline of its own, so
 * `signal` sets one. Pass `AbortSignal.timeout(...)` for a one-shot check, or a
 * controller you abort per keystroke when checking as the user types.
 *
 * @param domain - The organization domain.
 * @param signal - Bounds the check.
 * @returns Whether the domain is usable for SSO sign-in.
 * @throws When `signal` aborts — an abandoned check is not a verdict on the
 *   domain, so it must not be read as `false`.
 *
 * @example
 * if (await isValidSsoDomain(input.value, AbortSignal.timeout(5_000))) {
 *   const authClient = new AuthClient({ ssoDomain: input.value });
 *   await authClient.signIn();
 * }
 */
export async function isValidSsoDomain(domain: string, signal: AbortSignal): Promise<boolean> {
  signal.throwIfAborted();

  let normalized: string;
  try {
    normalized = normalizeSsoDomain(domain);
  } catch {
    return false;
  }

  const scheme = isLoopbackHost(normalized) ? 'http' : 'https';
  try {
    const response = await fetch(`${scheme}://${normalized}${WELL_KNOWN_PATH}`, {
      headers: { Accept: 'application/json' },
      signal,
    });
    if (!response.ok) {
      return false;
    }
    const valid = publishesSsoConfiguration(await response.json());
    signal.throwIfAborted();
    return valid;
  } catch (error) {
    if (signal.aborted) {
      throw error;
    }
    // A DNS, TLS, CORS, or parse failure all leave the domain unusable.
    return false;
  }
}
